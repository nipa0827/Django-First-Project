from django.shortcuts import render
from blog_post.models import Post

# Create your views here.

def home(request):
    return render(request,'index.html',{'all_post_lists':"Suravi",'disctrict':"Kishoreganj"})

def contact(request):
    return render(request,'contact.html')

def all_posts(request):
    posts = Post.objects.all()
    return render(request,'all_post.html',{'all_post_lists':posts})

def single_post(request,post_id):
    post = Post.objects.get(pk=post_id)

    return render(request,'single_post.html',{'post':post})

def contact(request):
    return render(request,'contact.html')

def about(request):
    return render(request,'about.html')

def services(request):
    return render(request,'services.html')