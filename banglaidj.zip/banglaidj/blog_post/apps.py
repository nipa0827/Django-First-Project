from django.apps import AppConfig


class BlogPostConfig(AppConfig):
    name = 'blog_post'
